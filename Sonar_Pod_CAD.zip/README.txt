SONAR TRANSMITTER POD - CAD PACKAGE   (units: mm)
Pod axis = +X, acoustic window (nose) at X=0, Z up, pod axis through the origin.
Pod: 400 mm long incl. cable stub (340 mm without), 90 mm OD, 122 mm tall incl. mount.

Sonar_Pod_only.step            30-body pod assembly (no hull)
Sonar_Pod_with_hull_ref.step   same + translucent hull section (dia 200, axis at Z=+165) for fit-check
.stl / .obj versions           mesh formats (Blender, MeshLab, CFD, 3D printing)
parts_STEP/, parts_STL/        every body as its own file
BOM.csv                        part list with suggested materials
Sonar_Pod_preview.png          render + cutaway

Layout along X: window 0-50 | transducer stack 30-53 (matching layer, 7x PZT, backing plate)
| tie rods + 2 driver boards + 4 HV caps + transformer 53-243 | end cap 240-282 with 2 O-rings
| flooded tail fairing 282-338 | connector + cable to 400.
Mount: NACA0015 pylon + curved saddle (R100) for a dia-200 hull.

STEP is faceted B-rep (triangles): fine for assembly, measurement, interference checks, sections;
not editable as sketches/fillets. Element sizes are placeholders, not acoustically validated.
